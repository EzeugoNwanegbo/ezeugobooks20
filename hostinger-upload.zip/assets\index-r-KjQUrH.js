const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-CVsNmNjL.js","assets/index-BMJL8sCO.js","assets/styles-3YvtiZYc.css"])))=>i.map(i=>d[i]);
import{r as e,_ as o}from"./index-BMJL8sCO.js";const _=e("Browser",{web:()=>o(()=>import("./web-CVsNmNjL.js"),__vite__mapDeps([0,1,2])).then(r=>new r.BrowserWeb)});export{_ as Browser};
