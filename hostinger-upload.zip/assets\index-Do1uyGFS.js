const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-CzN3iNhr.js","assets/index-BMJL8sCO.js","assets/styles-3YvtiZYc.css"])))=>i.map(i=>d[i]);
import{r as p,_ as r}from"./index-BMJL8sCO.js";const _=p("App",{web:()=>r(()=>import("./web-CzN3iNhr.js"),__vite__mapDeps([0,1,2])).then(e=>new e.AppWeb)});export{_ as App};
