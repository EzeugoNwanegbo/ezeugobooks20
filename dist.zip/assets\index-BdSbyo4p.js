const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-DX5pWP-0.js","assets/index-B30ZJ3xG.js","assets/styles-C4tccszL.css"])))=>i.map(i=>d[i]);
import{r as p,_ as r}from"./index-B30ZJ3xG.js";const _=p("App",{web:()=>r(()=>import("./web-DX5pWP-0.js"),__vite__mapDeps([0,1,2])).then(e=>new e.AppWeb)});export{_ as App};
