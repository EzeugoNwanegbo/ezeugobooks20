const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-DY0xS1V5.js","assets/index-B30ZJ3xG.js","assets/styles-C4tccszL.css"])))=>i.map(i=>d[i]);
import{r as e,_ as o}from"./index-B30ZJ3xG.js";const _=e("Browser",{web:()=>o(()=>import("./web-DY0xS1V5.js"),__vite__mapDeps([0,1,2])).then(r=>new r.BrowserWeb)});export{_ as Browser};
